<?php
$classFile = 'BCGcode93.barcode.php';
$className = 'BCGcode93';
$baseClassFile = 'BCGBarcode1D.php';
$codeVersion = '5.0.2';
?>